/* 
  File:   main.cpp
  Author: Angela Gomez
  Created on January 14, 2017,  6:35 PM
  Purpose: How much insurance?
       
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    
    int replacementCost;
    
    //Input values
    cout << "Enter the replacement cost of the building: "<< endl;
    cin >> replacementCost;
    cout << "You should buy: $" << .8 * replacementCost << endl;
    cout << "of property insurance." << endl;
   
  
    
    //Process by mapping inputs to outputs
 
    
    
    
    
     
    
    //Output values
  
    //Exit stage right!
    return 0;
}