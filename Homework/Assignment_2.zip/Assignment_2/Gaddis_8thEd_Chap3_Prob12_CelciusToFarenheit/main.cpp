/* 
  File:   main.cpp
  Author: Angela Gomez
  Created on January 13, 2017,  4:10 PM
  Purpose: Celsius to Farenheit
       
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    
    double Farenheit, celcius;
    
    cout << "What is your temperature in Celsius: " << endl;
    cin >> celcius;
     
    Farenheit = 9.0 / 5.0 * celcius + 32;
    
    cout << "Your temperature in Farenheit degrees is: " << Farenheit << endl;
    
    
    
   
  
    
    //Process by mapping inputs to outputs
   
    
    
    
     
    
    //Output values
  
    //Exit stage right!
    return 0;
}