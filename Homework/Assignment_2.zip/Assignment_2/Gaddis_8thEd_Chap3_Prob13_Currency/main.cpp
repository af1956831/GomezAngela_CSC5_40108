/* 
  File:   main.cpp
  Author: Angela Gomez
  Created on January 14, 2017, 11:30 AM
  Purpose:Currency 
       
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv) {
    //Declare Variables
    
    const double YEN_PER_DOLLAR = 98.93
    const double EUROS_PER_DOLLAR = 0.74
    double Yen, Euros;
    //Input 
    cout << setprecision(2) << fixed << showpoint;
   
    cout << "Enter the amount of Yen: " << endl;
    cin >> Yen
    cout << "Enter the amount of Euros: " << endl;
    cin >> Euros
    
    
    //Process by mapping inputs to outputs
 
    
    
    
    
     
    
    //Output values
  
    //Exit stage right!
    return 0;
}