/* 
  File:   main.cpp
  Author: Angela Gomez
  Created on January 9, 2017, 11:55 AM
  Purpose:  Template to be used in all programming
            projects!
 */

//Personal Information
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main(int argc, char** argv)
{  cout << "Angela Gomez\n";
cout << "7600 Ambergate Pl\n";
cout << "Riverside\n";
cout <<"California\n";
cout <<"92504\n";
cout <<"951-207-6162\n";
 
}