/* 
  File:   main.cpp
  Author: Angela Gomez
  Created on January 09, 2017, 07:00 AM
  Purpose:  Sum of Two Numbers
       
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants
//Such as PI, Vc, -> Math/Science values
//as well as conversions from system of units to 
//another

//Function Prototypes

//Executable code begins here!!!
int main()

{
    //Declare Variables
    int a, b, total;
    
    

    
    
    //Store numbers in variables
    a = 50, b = 100, total = 150;
    
    //Process by mapping inputs to outputs
    total = 50 + 100;
    
    //Output values
    cout << "A = 50"<<endl;
    cout << "B = 100"<<endl;
    cout << "total = " << total <<endl;

    //Exit stage right!
    return 0;
}